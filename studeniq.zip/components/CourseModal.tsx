import React from 'react';
import { X } from 'lucide-react';
import { Course } from '../data';

interface CourseModalProps {
  isOpen: boolean;
  onClose: () => void;
  course: Course | null;
}

const CourseModal: React.FC<CourseModalProps> = ({ isOpen, onClose, course }) => {
  if (!isOpen || !course) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-800 w-full max-w-md rounded-xl shadow-2xl overflow-hidden border border-slate-700 transform transition-all scale-100">
        <div className="p-6">
          <div className="flex justify-between items-start mb-4">
            <h3 className="text-xl font-bold text-slate-900 dark:text-white pr-4">
              {course.name}
            </h3>
            <button 
              onClick={onClose}
              className="text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white transition-colors"
            >
              <X size={24} />
            </button>
          </div>
          
          <div className="space-y-3">
            {course.duration && (
                <div className="inline-block bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 text-sm px-3 py-1 rounded-full font-medium">
                    {course.duration}
                </div>
            )}
            
            <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
              {course.notes || 'Resumo: matriz curricular organizada por semestres, com aulas teóricas e práticas. Consulte PPC para matriz completa.'}
            </p>
          </div>
          
          <div className="mt-6 text-right">
            <button 
              onClick={onClose}
              className="px-4 py-2 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-white rounded-lg hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors text-sm font-medium"
            >
              Fechar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseModal;