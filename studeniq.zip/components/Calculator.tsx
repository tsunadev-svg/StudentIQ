
import React, { useState, useEffect } from 'react';
import { CUSTOS, BAIRROS_POR_CIDADE, TRANSPORT_METRICS } from '../data';
import { AlertTriangle, CheckCircle, AlertCircle, Sparkles, Bus, Info } from 'lucide-react';

const Calculator: React.FC = () => {
  // Constants for calculation
  const WORKING_DAYS = 22;
  const DAILY_TRIPS = 2;

  // State
  const [faculty, setFaculty] = useState('');
  const [city, setCity] = useState('');
  const [neighborhood, setNeighborhood] = useState('');
  const [rent, setRent] = useState<string>('');
  const [materials, setMaterials] = useState<string>('');
  const [useRu, setUseRu] = useState(false);

  // Derived State
  const [transportCost, setTransportCost] = useState(0);
  const [foodCost, setFoodCost] = useState(0);
  const [total, setTotal] = useState(0);

  // Helper info state
  const [transportDetails, setTransportDetails] = useState('');

  // Status message logic
  const [status, setStatus] = useState({ 
    text: 'Aguardando dados...', 
    color: 'text-slate-500', 
    tip: 'Selecione a faculdade para começar a estimar seus gastos.' 
  });

  // Effect: Handle Faculty Constraints
  useEffect(() => {
    if (faculty === 'UNEX') {
      setCity('Itabuna');
      // If neighborhood was not in Itabuna, reset it
      if (!BAIRROS_POR_CIDADE['Itabuna'].includes(neighborhood)) {
        setNeighborhood('');
      }
    } else if (faculty === '' || (city === 'Itabuna' && faculty !== 'UNEX')) {
       // Optional: Relax city constraint if user switches away from UNEX
    }
  }, [faculty, city, neighborhood]);

  // Effect: Calculate Costs
  useEffect(() => {
    // 1. Transport Calculation Logic Refactored
    let calcTransport = 0;
    let details = '';

    if (city === 'Itabuna') {
      const { fare } = TRANSPORT_METRICS.ITABUNA;
      calcTransport = fare * DAILY_TRIPS * WORKING_DAYS;
      details = `Baseado em ${DAILY_TRIPS} passagens/dia por ${WORKING_DAYS} dias úteis (Tarifa R$ ${fare.toFixed(2)})`;
    } else if (city === 'Ilhéus') {
      if (neighborhood === 'Salobrinho') {
        calcTransport = 0;
        details = 'Isento (Distância caminhável / Circular gratuito)';
      } else {
        const { fare } = TRANSPORT_METRICS.ILHEUS;
        calcTransport = fare * DAILY_TRIPS * WORKING_DAYS;
        details = `Baseado em ${DAILY_TRIPS} passagens/dia por ${WORKING_DAYS} dias úteis (Tarifa R$ ${fare.toFixed(2)})`;
      }
    }
    
    // If no city selected, transport is 0
    if (!city) {
        calcTransport = 0;
        details = '';
    }

    setTransportCost(calcTransport);
    setTransportDetails(details);

    // 2. Food
    let calcFood = 0;
    if (faculty) {
      calcFood = CUSTOS.ALIMENTACAO_PADRAO;
      
      if (faculty === 'UNEX') {
        calcFood = CUSTOS.ALIMENTACAO_UNEX;
      } else if (faculty === 'UESC') {
        calcFood = useRu ? CUSTOS.CUSTO_RU : CUSTOS.ALIMENTACAO_PADRAO;
      }
      
      // Salobrinho Exception
      if (neighborhood === 'Salobrinho' && faculty !== 'UNEX') {
         calcFood = useRu ? CUSTOS.CUSTO_RU : CUSTOS.ALIMENTACAO_PADRAO;
      }
    }
    setFoodCost(calcFood);

    // 3. Total
    const numRent = parseFloat(rent.replace(/\./g, '').replace(',', '.') || '0');
    const numMaterials = parseFloat(materials.replace(/\./g, '').replace(',', '.') || '0');
    
    const calcTotal = numRent + numMaterials + calcTransport + calcFood;
    setTotal(calcTotal);

    // 4. Status Update
    if (faculty) {
        if (calcTotal <= 1200) {
            setStatus({
                text: 'Seus gastos estão baixos',
                color: 'text-green-400',
                tip: 'Excelente planejamento! Considere separar uma reserva de emergência.'
            });
        } else if (calcTotal <= 2200) {
            setStatus({
                text: 'Seus gastos estão moderados',
                color: 'text-yellow-400',
                tip: 'Se precisar economizar, reveja o valor do seu aluguel ou use o R.U.'
            });
        } else {
            let tip = 'ALERTA! Procure alternativas mais baratas de moradia e use o R.U. para economizar.';
            if (city === 'Ilhéus' && neighborhood !== 'Salobrinho') {
                tip = 'ALERTA! Morar em Salobrinho pode economizar cerca de R$ 200/mês no transporte.';
            }
            setStatus({
                text: 'Seus gastos estão altos',
                color: 'text-red-400',
                tip: tip
            });
        }
    } else {
        setStatus({ 
            text: 'Aguardando dados...', 
            color: 'text-slate-500', 
            tip: 'Selecione a faculdade para começar a estimar seus gastos.' 
        });
    }

  }, [faculty, city, neighborhood, rent, materials, useRu]);

  // Format Helper
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);
  };

  const handleMoneyInput = (val: string, setter: (v: string) => void) => {
     // Remove non-digits
     const raw = val.replace(/\D/g, '');
     if(!raw) {
         setter('');
         return;
     }
     const float = parseFloat(raw) / 100;
     setter(float.toLocaleString('pt-BR', { minimumFractionDigits: 2 }));
  };

  const showRuOption = (faculty === 'UESC') || (neighborhood === 'Salobrinho' && faculty !== 'UNEX');

  // Logic to find cheapest neighborhood based on transport
  const getNeighborhoodSuggestion = () => {
    // Current logic mainly favors Salobrinho for Ilhéus due to zero transport cost
    // Only suggest if user has already selected a neighborhood (that isn't Salobrinho)
    if (city === 'Ilhéus' && neighborhood && neighborhood !== 'Salobrinho') {
        const economy = (TRANSPORT_METRICS.ILHEUS.fare * DAILY_TRIPS * WORKING_DAYS) - 0; // Cost vs Free
        return {
            name: 'Salobrinho',
            amount: economy
        };
    }
    return null;
  };

  const suggestion = getNeighborhoodSuggestion();

  return (
    <div className="space-y-8">
        {/* Form Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
                <label className="text-sm font-semibold text-blue-300">Faculdade</label>
                <select 
                    value={faculty} 
                    onChange={(e) => setFaculty(e.target.value)}
                    className="w-full bg-slate-800/50 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                >
                    <option value="">Selecione...</option>
                    <option value="UNEX">UNEX</option>
                    <option value="UFSB">UFSB</option>
                    <option value="UESC">UESC</option>
                </select>
            </div>

            <div className="space-y-2">
                <label className="text-sm font-semibold text-blue-300">Cidade</label>
                <select 
                    value={city} 
                    onChange={(e) => {
                        setCity(e.target.value);
                        setNeighborhood('');
                    }}
                    disabled={!faculty || faculty === 'UNEX'}
                    className="w-full bg-slate-800/50 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    <option value="">Selecione...</option>
                    <option value="Itabuna">Itabuna</option>
                    <option value="Ilhéus">Ilhéus</option>
                </select>
            </div>

            <div className="space-y-2">
                <label className="text-sm font-semibold text-blue-300">Bairro</label>
                <select 
                    value={neighborhood} 
                    onChange={(e) => setNeighborhood(e.target.value)}
                    disabled={!city}
                    className="w-full bg-slate-800/50 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    <option value="">{city ? 'Selecione...' : 'Selecione Cidade'}</option>
                    {city && BAIRROS_POR_CIDADE[city]?.map(b => (
                        <option key={b} value={b}>{b}</option>
                    ))}
                </select>
                
                {suggestion && (
                    <button
                        onClick={() => setNeighborhood(suggestion.name)}
                        className="mt-2 w-full flex items-center justify-center gap-2 p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/20 transition-all text-xs text-left group animate-fade-in"
                        title={`Clique para selecionar ${suggestion.name}`}
                    >
                        <Sparkles size={14} className="group-hover:text-emerald-300 shrink-0" />
                        <span>
                            Economize <strong>{formatCurrency(suggestion.amount)}</strong> morando no <strong>{suggestion.name}</strong>
                        </span>
                    </button>
                )}
            </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
                <label className="text-sm font-semibold text-blue-300">Aluguel (Mensal)</label>
                <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">R$</span>
                    <input 
                        type="text" 
                        value={rent}
                        onChange={(e) => handleMoneyInput(e.target.value, setRent)}
                        placeholder="0,00"
                        disabled={!faculty}
                        className="w-full bg-slate-800/50 border border-slate-700 rounded-lg p-3 pl-10 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all disabled:opacity-50"
                    />
                </div>
            </div>

            <div className="space-y-2">
                <label className="text-sm font-semibold text-blue-300 flex items-center gap-2">
                    Transporte <span className="text-slate-500 font-normal text-xs">(Estimativa)</span>
                </label>
                <div className="w-full bg-slate-900/50 border border-slate-800 rounded-lg p-3 text-slate-300 cursor-not-allowed">
                    {formatCurrency(transportCost)}
                </div>
                {transportDetails && (
                    <div className="flex items-start gap-1.5 text-xs text-slate-500 mt-1.5">
                        <Info size={12} className="mt-0.5 shrink-0 text-blue-400" />
                        <span>{transportDetails}</span>
                    </div>
                )}
            </div>

            <div className="space-y-2">
                <label className="text-sm font-semibold text-blue-300">Alimentação</label>
                <div className="w-full bg-slate-900/50 border border-slate-800 rounded-lg p-3 text-slate-300 cursor-not-allowed">
                    {formatCurrency(foodCost)}
                </div>
            </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
                 <label className="text-sm font-semibold text-blue-300">Materiais (Mensal)</label>
                 <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">R$</span>
                    <input 
                        type="text" 
                        value={materials}
                        onChange={(e) => handleMoneyInput(e.target.value, setMaterials)}
                        placeholder="0,00"
                        disabled={!faculty}
                        className="w-full bg-slate-800/50 border border-slate-700 rounded-lg p-3 pl-10 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all disabled:opacity-50"
                    />
                 </div>
            </div>
        </div>

        {/* RU Option */}
        {showRuOption && (
            <div className="bg-blue-900/20 border border-blue-500/30 p-4 rounded-lg flex items-center gap-3 animate-fade-in">
                <input 
                    type="checkbox" 
                    id="ruCheck" 
                    checked={useRu}
                    onChange={(e) => setUseRu(e.target.checked)}
                    className="w-5 h-5 rounded border-slate-500 text-blue-600 focus:ring-blue-500 bg-slate-700"
                />
                <label htmlFor="ruCheck" className="text-sm text-blue-100 cursor-pointer select-none">
                    Desejo usar o Restaurante Universitário (R.U.) - Custo fixo de <strong>R$ 44,00/mês</strong>.
                </label>
            </div>
        )}

        {/* Result Box */}
        <div className="mt-8 bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-6 border border-slate-700 shadow-xl relative overflow-hidden">
            <div className="relative z-10 text-center">
                <h3 className="text-slate-400 text-sm uppercase tracking-widest font-semibold mb-2">Total Estimado Mensal</h3>
                <div className="text-4xl md:text-5xl font-bold text-white mb-4 tracking-tight">
                    {formatCurrency(total)}
                </div>
                
                <div className={`flex items-center justify-center gap-2 font-medium ${status.color}`}>
                   {status.color.includes('green') ? <CheckCircle size={20} /> : status.color.includes('red') ? <AlertTriangle size={20} /> : <AlertCircle size={20} />}
                   {status.text}
                </div>
                
                <p className="mt-4 text-slate-400 text-sm max-w-lg mx-auto bg-slate-900/50 py-2 px-4 rounded-full border border-slate-800">
                    {status.tip}
                </p>
            </div>
            
            {/* Background decoration */}
            <div className="absolute -top-24 -right-24 w-48 h-48 bg-blue-500/10 rounded-full blur-3xl"></div>
            <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-purple-500/10 rounded-full blur-3xl"></div>
        </div>
    </div>
  );
};

export default Calculator;