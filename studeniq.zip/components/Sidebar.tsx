
import React, { useState, useRef } from 'react';
import { UNIVERSITIES, Course } from '../data';
import CourseModal from './CourseModal';
import { ChevronRight, Info } from 'lucide-react';

const Sidebar: React.FC = () => {
  const [selectedFacId, setSelectedFacId] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const detailsRef = useRef<HTMLDivElement>(null);

  const selectedUniversity = UNIVERSITIES.find(u => u.id === selectedFacId);

  const handleFacClick = (id: string) => {
      setSelectedFacId(id);
      // Small delay to ensure render happens before scroll or active state settles
      setTimeout(() => {
          detailsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
  };

  const handleCourseClick = (course: Course) => {
    setSelectedCourse(course);
    setModalOpen(true);
  };

  return (
    <>
      <div className="flex flex-col gap-8">
        {/* List of Universities */}
        <div>
          <h3 className="text-blue-300 font-bold uppercase text-sm tracking-wider mb-4 border-b border-slate-700 pb-2">
            Faculdades da Região
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {UNIVERSITIES.map(uni => (
              <button
                key={uni.id}
                onClick={() => handleFacClick(uni.id)}
                className={`w-full text-left px-4 py-4 rounded-xl transition-all duration-300 flex items-center justify-between group border ${
                  selectedFacId === uni.id 
                    ? 'bg-blue-600/20 border-blue-500/50 text-white shadow-lg shadow-blue-900/20' 
                    : 'bg-slate-800/50 border-transparent text-slate-400 hover:bg-slate-800 hover:text-white hover:border-slate-700'
                }`}
              >
                <div className="flex flex-col">
                    <span className="font-bold text-sm md:text-base">{uni.name.split('—')[0].trim()}</span>
                    <span className="text-xs text-slate-500 group-hover:text-slate-400 mt-1">{uni.city} • {uni.type}</span>
                </div>
                <ChevronRight size={18} className={`transition-transform duration-300 ${selectedFacId === uni.id ? 'rotate-90 text-blue-400' : 'text-slate-600 group-hover:text-slate-300'}`} />
              </button>
            ))}
          </div>
        </div>

        {/* Selected University Details */}
        <div ref={detailsRef} className="animate-fade-in min-h-[300px]">
          {selectedUniversity ? (
            <div className="space-y-6 bg-slate-900/30 p-6 md:p-8 rounded-2xl border border-slate-700/50 shadow-inner">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                <div>
                    <h2 className="text-2xl font-bold text-white mb-2">{selectedUniversity.name}</h2>
                    <div className="flex flex-wrap items-center gap-2 text-sm text-slate-400">
                        <span className="bg-blue-900/30 text-blue-300 px-3 py-1 rounded-full text-xs font-semibold border border-blue-800/50">{selectedUniversity.type}</span>
                        <span>•</span>
                        <span>{selectedUniversity.city}</span>
                    </div>
                </div>
              </div>

              <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700/50">
                <h4 className="text-slate-400 text-xs uppercase font-bold mb-2 tracking-wider">Sobre a Instituição</h4>
                <p className="text-slate-300 leading-relaxed text-sm">
                    {selectedUniversity.summary}
                </p>
              </div>

              <div>
                <h4 className="text-blue-300 font-semibold text-lg mb-4 flex items-center gap-2">
                  <Info size={18} /> Cursos Disponíveis
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {selectedUniversity.courses.map(course => (
                    <div 
                      key={course.code} 
                      className="group flex flex-col justify-between p-3 rounded-lg bg-slate-900/50 border border-slate-800 hover:border-blue-500/30 hover:bg-slate-800/80 transition-all cursor-pointer"
                      onClick={() => handleCourseClick(course)}
                    >
                      <span className="text-sm font-medium text-slate-300 group-hover:text-white mb-2">{course.name}</span>
                      <div className="flex items-center justify-between mt-auto pt-2 border-t border-slate-800/50">
                         <span className="text-xs text-slate-500">{course.duration || 'Graduação'}</span>
                         <span className="text-xs text-blue-400 group-hover:text-blue-300 font-medium">Ver Detalhes</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="text-xs text-slate-500 mt-4 pt-4 border-t border-slate-800 flex items-center gap-2">
                <Info size={12} />
                <p>Informações baseadas nos portais oficiais e PPCs das instituições. Grade sujeita a alterações.</p>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-16 text-slate-500 bg-slate-800/20 rounded-2xl border-2 border-dashed border-slate-700/50 hover:bg-slate-800/30 transition-colors">
              <div className="bg-slate-800 p-4 rounded-full mb-4">
                  <Info className="text-blue-500 opacity-80" size={32} />
              </div>
              <p className="text-lg font-medium text-slate-400">Nenhuma faculdade selecionada</p>
              <p className="text-sm opacity-70 mt-1">Clique em uma das opções acima para ver detalhes e cursos.</p>
            </div>
          )}
        </div>
      </div>

      <CourseModal 
        isOpen={modalOpen} 
        onClose={() => setModalOpen(false)} 
        course={selectedCourse} 
      />
    </>
  );
};

export default Sidebar;