
import React from 'react';
import { Link } from 'react-router-dom';
import { Building2, GraduationCap, BookOpen, ArrowRight } from 'lucide-react';

const Home: React.FC = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-6 md:px-12 overflow-hidden">
        {/* Background glow effects */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[600px] bg-blue-600/10 rounded-full blur-[100px] -z-10 pointer-events-none"></div>
        <div className="absolute bottom-0 right-0 w-[600px] h-[500px] bg-purple-600/10 rounded-full blur-[100px] -z-10 pointer-events-none"></div>

        <div className="container mx-auto flex flex-col items-center text-center relative z-10">
          <div className="max-w-4xl">
            <h1 className="text-4xl md:text-6xl font-extrabold leading-tight mb-6">
              Planeje seu futuro com <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-500">inteligência financeira</span>
            </h1>
            <p className="text-lg text-slate-400 mb-10 leading-relaxed max-w-2xl mx-auto">
              Descubra quanto você gastará estudando em Itabuna ou Ilhéus. O StudenIQ ajuda você a estimar custos de moradia, transporte e alimentação para as principais universidades da região.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link 
                to="/simulator" 
                className="px-8 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold rounded-xl shadow-lg shadow-blue-500/25 transition-all transform hover:-translate-y-1 flex items-center justify-center gap-2"
              >
                Iniciar Simulação <ArrowRight size={20} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Info Section */}
      <section id="about" className="py-20 bg-slate-900/50 border-y border-slate-800">
        <div className="container mx-auto px-6 text-center max-w-4xl">
          <h3 className="text-3xl font-bold text-white mb-6">Sobre o Projeto</h3>
          <p className="text-slate-400 text-lg leading-relaxed">
            O <strong>StudenIQ</strong> foi criado para simplificar a vida do estudante sul-baiano. 
            Sabemos que escolher uma faculdade vai além da grade curricular; envolve planejamento financeiro real.
            Nossa ferramenta utiliza dados atualizados do mercado local para fornecer estimativas precisas.
          </p>
        </div>
      </section>

      {/* Cards Section */}
      <section className="py-20 px-6">
        <div className="container mx-auto">
          <h3 className="text-2xl md:text-3xl font-bold text-center text-white mb-16">
            Faculdades e Cidades
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-slate-800/40 backdrop-blur-sm border border-slate-700 p-8 rounded-2xl hover:border-blue-500/50 transition-colors group">
              <div className="w-14 h-14 bg-blue-900/30 rounded-lg flex items-center justify-center mb-6 group-hover:bg-blue-600 group-hover:text-white text-blue-400 transition-colors">
                <Building2 size={32} />
              </div>
              <h4 className="text-xl font-bold text-white mb-3">UNEX</h4>
              <p className="text-slate-400 leading-relaxed">
                Localizada em Itabuna, oferece cursos de graduação com fácil acesso e infraestrutura moderna.
              </p>
            </div>

            <div className="bg-slate-800/40 backdrop-blur-sm border border-slate-700 p-8 rounded-2xl hover:border-purple-500/50 transition-colors group">
              <div className="w-14 h-14 bg-purple-900/30 rounded-lg flex items-center justify-center mb-6 group-hover:bg-purple-600 group-hover:text-white text-purple-400 transition-colors">
                <GraduationCap size={32} />
              </div>
              <h4 className="text-xl font-bold text-white mb-3">UESC</h4>
              <p className="text-slate-400 leading-relaxed">
                Entre Ilhéus e Itabuna. Conta com Restaurante Universitário (R.U.) acessível e transporte via Salobrinho.
              </p>
            </div>

            <div className="bg-slate-800/40 backdrop-blur-sm border border-slate-700 p-8 rounded-2xl hover:border-indigo-500/50 transition-colors group">
              <div className="w-14 h-14 bg-indigo-900/30 rounded-lg flex items-center justify-center mb-6 group-hover:bg-indigo-600 group-hover:text-white text-indigo-400 transition-colors">
                <BookOpen size={32} />
              </div>
              <h4 className="text-xl font-bold text-white mb-3">UFSB</h4>
              <p className="text-slate-400 leading-relaxed">
                Com campus em Ilhéus, oferece ensino público federal de excelência e incentiva a mobilidade acadêmica.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
