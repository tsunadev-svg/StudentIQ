
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Sidebar from '../components/Sidebar';
import Calculator from '../components/Calculator';
import { ChevronLeft, Calculator as CalcIcon, School, Lightbulb, Bus } from 'lucide-react';
import { TRANSPORT_METRICS } from '../data';

type Tab = 'custos' | 'universidades' | 'dicas';

const Simulator: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('custos');

  return (
    <div className="min-h-screen pt-24 pb-12 px-4 md:px-8">
      <div className="container mx-auto max-w-5xl">
        
        {/* Header Section */}
        <div className="mb-8">
             <Link to="/" className="inline-flex items-center text-slate-400 hover:text-white transition-colors mb-4 text-sm font-medium">
                <ChevronLeft size={16} className="mr-1" /> Voltar à Tela Inicial
             </Link>
             <h1 className="text-3xl md:text-4xl font-bold text-white mb-2 tracking-tight">Simulador Universitário</h1>
             <p className="text-slate-400 text-lg">
                Planeje sua jornada acadêmica com estimativas reais de custos.
             </p>
        </div>

        {/* Tab Navigation - Fixed behavior adjustments */}
        <div className="flex p-1 gap-1 bg-slate-900/95 rounded-xl border border-slate-700 mb-8 sticky top-20 z-30 backdrop-blur-xl shadow-lg transition-all">
            <button 
                onClick={() => setActiveTab('custos')}
                className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-lg text-xs sm:text-sm font-semibold transition-all duration-200 whitespace-nowrap ${
                    activeTab === 'custos' 
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-900/20' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
            >
                <CalcIcon size={18} className="shrink-0" />
                <span className="hidden sm:inline">Calculadora</span>
                <span className="sm:hidden">Custos</span>
            </button>
            <button 
                onClick={() => setActiveTab('universidades')}
                className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-lg text-xs sm:text-sm font-semibold transition-all duration-200 whitespace-nowrap ${
                    activeTab === 'universidades' 
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-900/20' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
            >
                <School size={18} className="shrink-0" />
                <span className="hidden sm:inline">Universidades</span>
                <span className="sm:hidden">Faculdades</span>
            </button>
            <button 
                onClick={() => setActiveTab('dicas')}
                className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-lg text-xs sm:text-sm font-semibold transition-all duration-200 whitespace-nowrap ${
                    activeTab === 'dicas' 
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-900/20' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
            >
                <Lightbulb size={18} className="shrink-0" />
                <span className="hidden sm:inline">Dicas & Moradia</span>
                <span className="sm:hidden">Dicas</span>
            </button>
        </div>

        {/* Content Area */}
        <div className="bg-slate-800/40 backdrop-blur-md border border-slate-700 rounded-2xl p-6 md:p-8 min-h-[500px] shadow-2xl relative overflow-hidden">
            
            {/* Ambient Background Glow */}
            <div className="absolute -top-[200px] -right-[200px] w-[400px] h-[400px] bg-blue-500/5 rounded-full blur-3xl pointer-events-none"></div>

            {activeTab === 'custos' && (
                <div className="animate-fade-in relative z-10">
                    <div className="mb-8 border-b border-slate-700/60 pb-6">
                        <h2 className="text-2xl font-bold text-white mb-2 flex items-center gap-2">
                            <CalcIcon className="text-blue-400" /> Calculadora Financeira
                        </h2>
                        <p className="text-slate-400 leading-relaxed max-w-3xl">
                             Selecione sua faculdade e cidade para obter uma estimativa de gastos mensais. 
                             O cálculo considera <strong>transporte</strong>, <strong>alimentação</strong> (com regras de R.U.) e sua estimativa de <strong>aluguel</strong>.
                        </p>
                    </div>
                    <Calculator />
                </div>
            )}

            {activeTab === 'universidades' && (
                 <div className="animate-fade-in relative z-10">
                    <Sidebar />
                 </div>
            )}

            {activeTab === 'dicas' && (
                <div className="animate-fade-in space-y-10 relative z-10">
                    
                    {/* Section: Info */}
                    <div>
                        <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                             <Lightbulb className="text-yellow-400" /> Guia de Sobrevivência
                        </h2>
                        
                        {/* Public Transport Info Card */}
                        <div className="bg-slate-900/40 p-6 rounded-2xl border border-slate-700/50 hover:border-slate-600 transition-colors mb-6">
                            <h4 className="text-blue-400 font-bold mb-4 text-lg border-b border-slate-800 pb-2 flex items-center gap-2">
                                <Bus size={20} /> Transporte Público
                            </h4>
                            <div className="grid md:grid-cols-2 gap-8">
                                <div>
                                    <h5 className="font-semibold text-white mb-2">Itabuna</h5>
                                    <p className="text-sm text-slate-400 mb-2">Empresa: <span className="text-slate-300">{TRANSPORT_METRICS.ITABUNA.company}</span></p>
                                    <p className="text-sm text-slate-400 mb-2">Tarifa Base: <span className="text-green-400 font-bold">R$ {TRANSPORT_METRICS.ITABUNA.fare.toFixed(2)}</span></p>
                                    <p className="text-xs text-slate-500 mb-3">{TRANSPORT_METRICS.ITABUNA.description}</p>
                                    <div className="text-xs text-slate-400">
                                        <span className="block mb-1 font-medium text-slate-300">Principais Linhas:</span>
                                        <div className="flex flex-wrap gap-2">
                                            {TRANSPORT_METRICS.ITABUNA.mainLines.map(line => (
                                                <span key={line} className="px-2 py-1 bg-slate-800 rounded text-slate-300">{line}</span>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                                <div className="md:border-l md:border-slate-800 md:pl-8">
                                    <h5 className="font-semibold text-white mb-2">Ilhéus</h5>
                                    <p className="text-sm text-slate-400 mb-2">Empresas: <span className="text-slate-300">{TRANSPORT_METRICS.ILHEUS.company}</span></p>
                                    <p className="text-sm text-slate-400 mb-2">Tarifa Base: <span className="text-green-400 font-bold">R$ {TRANSPORT_METRICS.ILHEUS.fare.toFixed(2)}</span></p>
                                    <p className="text-xs text-slate-500 mb-3">{TRANSPORT_METRICS.ILHEUS.description}</p>
                                    <div className="text-xs text-slate-400">
                                        <span className="block mb-1 font-medium text-slate-300">Principais Linhas:</span>
                                        <div className="flex flex-wrap gap-2">
                                            {TRANSPORT_METRICS.ILHEUS.mainLines.map(line => (
                                                <span key={line} className="px-2 py-1 bg-slate-800 rounded text-slate-300">{line}</span>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="grid md:grid-cols-2 gap-6">
                            <div className="bg-slate-900/40 p-6 rounded-2xl border border-slate-700/50 hover:border-slate-600 transition-colors">
                                <h4 className="text-blue-400 font-bold mb-4 text-lg border-b border-slate-800 pb-2">📍 Cidades e Bairros</h4>
                                <ul className="space-y-4">
                                    <li className="text-sm text-slate-300">
                                        <strong className="block text-white mb-1">Itabuna</strong> 
                                        Centro, Santo Antônio e São Caetano são os mais procurados por estudantes da UNEX e FTC pela proximidade e serviços.
                                    </li>
                                    <li className="text-sm text-slate-300">
                                        <strong className="block text-white mb-1">Ilhéus</strong> 
                                        Centro e Zona Sul (Pontal) oferecem boa qualidade de vida, mas custos mais altos. A Zona Norte é mais distante das faculdades principais.
                                    </li>
                                    <li className="text-sm text-slate-300">
                                        <strong className="block text-white mb-1">Salobrinho (Ilhéus)</strong> 
                                        Bairro universitário ao lado da UESC. Transporte gratuito (circular) para o campus, aluguéis acessíveis, porém vida noturna e serviços limitados.
                                    </li>
                                </ul>
                            </div>

                            <div className="bg-slate-900/40 p-6 rounded-2xl border border-slate-700/50 hover:border-slate-600 transition-colors">
                                <h4 className="text-green-400 font-bold mb-4 text-lg border-b border-slate-800 pb-2">💰 Dicas de Economia</h4>
                                <ul className="space-y-4">
                                    <li className="text-sm text-slate-300">
                                        <strong className="block text-white mb-1">Restaurante Universitário (R.U.)</strong> 
                                        A UESC possui R.U. com custo baixíssimo (subsidiado). Estudantes da UFSB e particulares geralmente gastam mais com alimentação (marmitas ou self-service).
                                    </li>
                                    <li className="text-sm text-slate-300">
                                        <strong className="block text-white mb-1">Transporte Inteligente</strong> 
                                        Morar perto da faculdade economiza cerca de R$ 160-200 mensais. Se estudar na UESC, morar no Salobrinho zera o custo de transporte diário.
                                    </li>
                                    <li className="text-sm text-slate-300">
                                        <strong className="block text-white mb-1">Repúblicas</strong> 
                                        Dividir apartamento é a regra de ouro. Pode reduzir o custo de aluguel e contas (internet, luz) em até 50%.
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    {/* Section: WhatsApp */}
                    <div className="bg-gradient-to-r from-green-900/20 to-slate-900/20 p-8 rounded-2xl border border-green-900/30">
                         <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6 gap-4">
                            <div>
                                <h3 className="text-xl font-bold text-white">Grupos de WhatsApp</h3>
                                <p className="text-slate-400 text-sm mt-1">Conecte-se com outros estudantes para encontrar moradia ou dividir despesas.</p>
                            </div>
                            <span className="px-3 py-1 bg-green-500/20 text-green-400 text-xs font-bold uppercase tracking-wide rounded-full border border-green-500/30">Comunidade Ativa</span>
                         </div>
                         
                         <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
                            <a href="#" className="flex items-center justify-center px-4 py-4 bg-slate-800 hover:bg-green-600 hover:text-white text-slate-300 border border-slate-700 hover:border-green-500 rounded-xl transition-all font-medium group shadow-lg">
                                <span className="mr-3 text-xl group-hover:scale-110 transition-transform">🏠</span> Moradia Itabuna
                            </a>
                            <a href="#" className="flex items-center justify-center px-4 py-4 bg-slate-800 hover:bg-green-600 hover:text-white text-slate-300 border border-slate-700 hover:border-green-500 rounded-xl transition-all font-medium group shadow-lg">
                                <span className="mr-3 text-xl group-hover:scale-110 transition-transform">🌊</span> Moradia Ilhéus
                            </a>
                            <a href="#" className="flex items-center justify-center px-4 py-4 bg-green-600 text-white border border-green-500 rounded-xl transition-all font-bold shadow-lg shadow-green-900/50 hover:bg-green-500 hover:scale-[1.02]">
                                <span className="mr-3 text-xl">🎓</span> Moradia Salobrinho
                            </a>
                        </div>
                    </div>
                </div>
            )}

        </div>

      </div>
    </div>
  );
};

export default Simulator;
